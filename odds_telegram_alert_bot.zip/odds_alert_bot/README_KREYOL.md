# 1X2 Odds → Telegram Alert

Objektif: tcheke match foutbòl yo epi voye yon mesaj Telegram lè **pi gwo kòt 1, X ak 2 yo, atravè bookmaker EU yo, tout > 3.00**.

### Sa ki nesesè
1. The Odds API key ou.
2. Yon Telegram Bot Token.
3. Telegram Chat ID ou.
4. Yon kont GitHub pou GitHub Actions.

### Sekirite
**Pa mete API key oswa Telegram Bot Token nan fichye yo.** Mete yo kòm GitHub Secrets:
- `ODDS_API_KEY`
- `TG_BOT_TOKEN`
- `TG_CHAT_ID`

### Telegram
Nan Telegram, chèche **@BotFather**, voye `/newbot`, epi swiv etap yo pou kreye bot la. BotFather ap ba w token an.

Apre sa, ouvri chat ak nouvo bot la epi voye `/start`.

Pou jwenn Chat ID a, sèvi ak `getUpdates` Bot API oswa yon zouti lokal ki li dènye mesaj ou voye bay bot la. Chat ID a se valè `message.chat.id`.

### Dat
Scanner la sipòte:
- `TODAY` = tout match nan dat jodi a (lè Ayiti)
- `TOMORROW` = demen
- `BOTH` = jodi a + demen
- `DATE` = yon dat espesifik, eg. `2026-10-05`

Lè w lanse workflow la manyèlman nan GitHub, ou ka chwazi mòd la nan **Run workflow**.

### Kijan alèt la mache
Pou chak match, scanner la pran pi gwo kòt 1, X ak 2 li jwenn nan bookmaker EU yo. Li montre bookmaker ki bay chak pi gwo kòt.

Egzanp:

`1 = 3.10 — Bookmaker A`
`X = 3.25 — Bookmaker B`
`2 = 3.08 — Bookmaker C`
`🚨 3 KÒT > 3.00`

Sa **pa vle di yon bookmaker sèl** ap bay tout 3 kòt yo. Se yon konparezon atravè bookmaker yo.

### Kredi API
The Odds API dokimante `/sports` ak `/events` kòm endpoints ki pa konte nan quota a. `/odds` koute 1 credit pou chak region + market; nou itilize 1 region (`eu`) ak 1 market (`h2h`), konsa yon odds call nòmal koute 1 credit. Scanner la gen `MAX_ODDS_CALLS=25` kòm yon limit pwoteksyon pou yon sèl kouri.

Avèk plan gratis la, pa mete yon entèval twò kout san w pa verifye konbyen leagues ki gen match ak konbyen credits ki rete.
