import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import requests

BASE = "https://api.the-odds-api.com/v4"
HAITI_TZ = ZoneInfo("America/Port-au-Prince")
STATE_FILE = Path("alert_state.json")


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(1)


def get_env(name: str, required: bool = True, default: str = "") -> str:
    value = os.environ.get(name, default).strip()
    if required and not value:
        die(f"Missing GitHub Secret/Variable: {name}")
    return value


def local_day_bounds(date_str: str):
    day = datetime.strptime(date_str, "%Y-%m-%d").date()
    start = datetime(day.year, day.month, day.day, tzinfo=HAITI_TZ)
    end = start + timedelta(days=1)
    return start.astimezone(timezone.utc), end.astimezone(timezone.utc)


def target_dates(mode: str, custom_date: str):
    today = datetime.now(HAITI_TZ).date()
    if mode == "TODAY":
        return [today.strftime("%Y-%m-%d")]
    if mode == "TOMORROW":
        return [(today + timedelta(days=1)).strftime("%Y-%m-%d")]
    if mode == "BOTH":
        return [today.strftime("%Y-%m-%d"), (today + timedelta(days=1)).strftime("%Y-%m-%d")]
    if mode == "DATE":
        try:
            datetime.strptime(custom_date, "%Y-%m-%d")
        except ValueError:
            die("CUSTOM_DATE must be YYYY-MM-DD")
        return [custom_date]
    die("SCAN_MODE must be TODAY, TOMORROW, BOTH or DATE")


def api_get(path: str, api_key: str, params=None):
    params = dict(params or {})
    params["apiKey"] = api_key
    url = f"{BASE}{path}"
    r = requests.get(url, params=params, timeout=30)
    remaining = r.headers.get("x-requests-remaining")
    if remaining is not None:
        print(f"Quota remaining: {remaining}")
    if r.status_code != 200:
        try:
            data = r.json()
            msg = data.get("message") or data
        except Exception:
            msg = r.text[:500]
        raise RuntimeError(f"API {r.status_code}: {msg}")
    return r.json(), remaining


def soccer_sports(api_key: str):
    sports, _ = api_get("/sports/", api_key)
    result = []
    for s in sports:
        group = str(s.get("group", "")).lower()
        key = str(s.get("key", ""))
        if "soccer" in group or key.startswith("soccer_"):
            result.append(s)
    result.sort(key=lambda x: (str(x.get("title", "")), str(x.get("key", ""))))
    return result


def events_for_sport(api_key: str, sport_key: str, start_utc: datetime, end_utc: datetime):
    data, _ = api_get(
        f"/sports/{sport_key}/events/",
        api_key,
        {
            "dateFormat": "iso",
            "commenceTimeFrom": start_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "commenceTimeTo": end_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
        },
    )
    return data


def odds_for_sport(api_key: str, sport_key: str, start_utc: datetime, end_utc: datetime):
    data, remaining = api_get(
        f"/sports/{sport_key}/odds/",
        api_key,
        {
            "regions": "eu",
            "markets": "h2h",
            "oddsFormat": "decimal",
            "dateFormat": "iso",
            "commenceTimeFrom": start_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "commenceTimeTo": end_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
        },
    )
    return data, int(remaining) if remaining is not None else None


def extract_cross_bookmaker(event):
    home = event.get("home_team", "")
    away = event.get("away_team", "")
    best = {"1": None, "X": None, "2": None}
    draw_names = {"draw", "tie", "x", "empate", "match nul", "nul"}

    for bookmaker in event.get("bookmakers", []):
        btitle = bookmaker.get("title") or bookmaker.get("key") or "Unknown"
        for market in bookmaker.get("markets", []):
            if market.get("key") != "h2h":
                continue
            for outcome in market.get("outcomes", []):
                name = str(outcome.get("name", ""))
                price = outcome.get("price")
                if not isinstance(price, (int, float)):
                    continue
                slot = None
                if name == home:
                    slot = "1"
                elif name == away:
                    slot = "2"
                elif name.strip().lower() in draw_names:
                    slot = "X"
                if slot and (best[slot] is None or price > best[slot]["price"]):
                    best[slot] = {"price": float(price), "bookmaker": btitle}
    if not all(best.values()):
        return None
    return best


def is_qualifying(best):
    return best["1"]["price"] > 3.0 and best["X"]["price"] > 3.0 and best["2"]["price"] > 3.0


def load_state():
    if not STATE_FILE.exists():
        return set()
    try:
        data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        return set(data.get("active_alerts", []))
    except Exception:
        return set()


def save_state(active):
    STATE_FILE.write_text(json.dumps({"active_alerts": sorted(active)}, indent=2), encoding="utf-8")


def telegram_send(bot_token: str, chat_id: str, text: str):
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    r = requests.post(
        url,
        json={"chat_id": chat_id, "text": text, "disable_web_page_preview": True},
        timeout=20,
    )
    if r.status_code != 200:
        try:
            msg = r.json()
        except Exception:
            msg = r.text[:500]
        raise RuntimeError(f"Telegram error {r.status_code}: {msg}")


def format_alert(event, best):
    commence = event.get("commence_time", "")
    try:
        dt = datetime.fromisoformat(commence.replace("Z", "+00:00")).astimezone(HAITI_TZ)
        local_time = dt.strftime("%d/%m/%Y %H:%M")
    except Exception:
        local_time = commence
    return (
        "🚨 3 KÒT > 3.00\n\n"
        f"⚽ {event.get('home_team','')} vs {event.get('away_team','')}\n"
        f"🕒 Haiti: {local_time}\n\n"
        f"1: {best['1']['price']:.2f} — {best['1']['bookmaker']}\n"
        f"X: {best['X']['price']:.2f} — {best['X']['bookmaker']}\n"
        f"2: {best['2']['price']:.2f} — {best['2']['bookmaker']}\n\n"
        "Règ la: 1, X ak 2 yo dwe tout > 3.00.\n"
        "Sa se yon alèt sou kòt yo sèlman; li pa garanti yon pwofi oswa yon rezilta match."
    )


def main():
    api_key = get_env("ODDS_API_KEY")
    bot_token = get_env("TG_BOT_TOKEN")
    chat_id = get_env("TG_CHAT_ID")
    mode = get_env("SCAN_MODE", required=False, default="TODAY").upper()
    custom_date = get_env("CUSTOM_DATE", required=False, default="")
    max_calls = int(get_env("MAX_ODDS_CALLS", required=False, default="25"))

    dates = target_dates(mode, custom_date)
    sports = soccer_sports(api_key)
    print(f"Soccer leagues/sports found: {len(sports)}")
    previous_active = load_state()
    new_active = set()
    sent = 0
    odds_calls = 0
    errors = []

    for date_str in dates:
        start, end = local_day_bounds(date_str)
        print(f"Scanning {date_str} ({mode})")
        for sport in sports:
            sport_key = sport.get("key")
            if not sport_key:
                continue
            try:
                events = events_for_sport(api_key, sport_key, start, end)
            except Exception as e:
                errors.append(f"{sport_key}: events: {e}")
                continue
            if not events:
                continue
            if odds_calls >= max_calls:
                print(f"Reached MAX_ODDS_CALLS={max_calls}; stopping to protect quota.")
                break
            try:
                odds_data, remaining = odds_for_sport(api_key, sport_key, start, end)
                odds_calls += 1
            except Exception as e:
                errors.append(f"{sport_key}: odds: {e}")
                continue

            for event in odds_data:
                best = extract_cross_bookmaker(event)
                if not best:
                    continue
                key = f"{event.get('id','')}:{date_str}"
                if is_qualifying(best):
                    new_active.add(key)
                    if key not in previous_active:
                        try:
                            telegram_send(bot_token, chat_id, format_alert(event, best))
                            sent += 1
                            print(f"ALERT SENT: {event.get('home_team')} vs {event.get('away_team')}")
                        except Exception as e:
                            errors.append(f"telegram: {e}")
            if remaining is not None and remaining <= 0:
                break
        
    save_state(new_active)
    print(f"Odds calls used this run: {odds_calls}")
    print(f"New Telegram alerts sent: {sent}")
    print(f"Active qualifying events after scan: {len(new_active)}")
    if errors:
        print("Warnings/errors:")
        for err in errors[:20]:
            print("-", err)


if __name__ == "__main__":
    main()
